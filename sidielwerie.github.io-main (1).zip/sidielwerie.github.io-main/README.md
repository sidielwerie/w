# The source of ebazhanov.github.io

This repository contains the source code of [ebazhanov.github.io](https://ebazhanov.github.io/).

## Development

1. Run `bundle install`
2. Run `bundle exec jekyll serve`
3. Open http://localhost:4000

## Deployment

1. Push to master branch
2. GitHub Pages at https://github.com/ebazhanov/ebazhanov.github.io will build and deploy the website

## Credits

Website based on https://github.com/YoussefRaafatNasry/portfolYOU. Thanks!
# laliweb0.github.io
# laliweb0.github.io
# sidielwerie.github.io
# sidielwerie.github.io
# sidielwerie.github.io
# sidielwerie.github.io
# sidielwerie.github.io
# sidielwerie.github.io
# sidielwerie.github.io
