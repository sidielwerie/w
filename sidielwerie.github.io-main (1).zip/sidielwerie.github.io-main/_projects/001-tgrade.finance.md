---
name: dApp
tools: [Typescript, React, Dependencies, CosmWasm]
description: >
  Tgrade - building a secure, regulatory friendly, decentralised finance platform.
external_url: https://tgrade.finance/
---
