---
name: Fernarzt
tools: [Typescript, CMS, React]
description: >
    Fernarzt is a telemedicine platform that puts patients in touch with doctors 
    and then coordinates the purchase of medication prescribed in the treatment relationship. 
external_url: https://www.fernarzt.com/
---
