---
name: Search for Quiz
tools: [Typescript, React]
description: >
    List of quizzes with search functionality
external_url: https://github.com/linkedin-faq/search-linkedin-quiz
---
