---
name: Notes App
tools: [Typescript, React]
description: >
    Create notes Web app
external_url: https://github.com/Ebazhanov/notes-app
---