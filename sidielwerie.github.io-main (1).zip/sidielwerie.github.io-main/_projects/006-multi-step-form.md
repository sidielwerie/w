---
name: Multi steps form
tools: [Typescript, React, Mui]
description: >
    Registration form with 2 steps and confirmation alert
external_url: https://github.com/Ebazhanov/multi-steps-form-formik-mui
---