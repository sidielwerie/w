---
name: Landing page
tools: [Typescript, React, TailwindCSS]
description: >
    Template for Landing page based on TS and TailwindCSS
external_url: https://github.com/Ebazhanov/nextjs-tailwind-landing-page
---