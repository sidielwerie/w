---
layout: page
title: À propos
permalink: /about/
weight: 3
---

# Heyho, Sidi est là! 👋
<br />

Je suis étudiant en Génie Industriel et Informatique, actuellement en stage chez Perfectstay en tant que Product Owner.<br>
<br />
Après avoir terminé mon stage, j'ai hâte de commencer ma carrière en gestion de produits.
 

<div class="row">
{% include about/skills.html title="Compétences :" source=site.data.programming-skills %}


</div>

Parcours :
<div class="row">

{% include about/timeline.html title="" %}

</div>

